import { Component, Inject, OnInit } from '@angular/core';
import { Receita } from '../models/receita.model';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Comentario } from '../models/comentario.model';

@Component({
  selector: 'app-detalhes',
  templateUrl: './detalhes.component.html',
  styleUrls: ['./detalhes.component.css']
})
export class DetalhesComponent implements OnInit {
  public comentarios: Comentario[] = [];
  public novoComentario: Comentario = { id: 0, idreceita: 0, idutilizador: 0, comentario: "" };

  constructor(private http: HttpClient, private route: ActivatedRoute, @Inject('BASE_URL') private baseUrl: string) { }

  public receita: Receita = { id: 0, nome: "", instrucoes: "", ingredientes: "", url: "" };

  ngOnInit(): void {
    this.loadReceitas();
    this.loadComentarios();
  }

  loadReceitas() {
    this.route.params.subscribe(params => {
      this.http.get<Receita>(this.baseUrl + 'ReceitaModels/' + params['id']).subscribe(
        result => {
          this.receita = result;
          console.log(result);
        },
        error => console.error(error)
      );
    });
  }

  loadComentarios() {
    const idReceita = this.receita.id;

    this.http.get<Comentario[]>(this.baseUrl + 'ComentarioModels?idreceita=' + idReceita).subscribe(
      result => {
        this.comentarios = result;
        console.log(result);
      },
      error => console.error(error)
    );
  }

  adicionarComentario() {
    const idUtilizador = 0; 
    this.novoComentario.idreceita = this.receita.id;
    this.novoComentario.idutilizador = idUtilizador;
    this.http.post<Comentario>(this.baseUrl + 'ComentarioModels', this.novoComentario).subscribe(
      result => {
        console.log('Comentário adicionado:', result);
        this.novoComentario.comentario = ""; 
        this.loadComentarios(); 
      },
      error => console.error('Erro ao adicionar comentário:', error)
    );
  }
}
