import { Component, Inject, OnInit } from '@angular/core';
import { Receita } from '../models/receita.model';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editar-receitas', 
  templateUrl: './editar-receita.component.html', 
  styleUrls: ['./editar-receita.component.css'] 
})
export class EditarReceitaComponent implements OnInit {
  constructor(private http: HttpClient, private route: ActivatedRoute, @Inject('BASE_URL') private baseUrl: string) { }

  public receita: Receita = { id: 0, nome: '', instrucoes: '', ingredientes: '', url: '' };

  ngOnInit(): void {
    this.loadReceita();
  }

  loadReceita() {
    this.route.params.subscribe(params => {
      this.http.get<Receita>(this.baseUrl + 'ReceitaModels/' + params['id']).subscribe(
        result => {
          this.receita = result;
          console.log(result);
        },
        error => console.error(error)
      );
    });
  }

  atualizarReceita() {
    this.http.put(this.baseUrl + 'ReceitaModels/' + this.receita.id, this.receita).subscribe(
      () => {
        console.log('Receita atualizada:', this.receita);
      
      },
      () => {
        console.log('Erro ao atualizar receita');
        
      }
    );
  }
}
