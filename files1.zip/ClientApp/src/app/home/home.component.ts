import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Receita } from '../models/receita.model'


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  public receitas: Receita[] = [];
  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    http.get<Receita[]>(baseUrl + 'ReceitaModels').subscribe(result => {
      this.receitas = result;
    }, error => console.error(error));
  }
}
