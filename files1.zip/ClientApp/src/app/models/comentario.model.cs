﻿namespace DiogoNovo.ClientApp.src.app.models
{
    public class comentario
    {
    }
}
