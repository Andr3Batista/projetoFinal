
export interface Comentario {
  id: number;
  idreceita: number;
  idutilizador: number;
  comentario: string;
}
