export interface Receita {
  id: number;
  nome: string;
  instrucoes: string;
  ingredientes: string;
  url: string;
}
