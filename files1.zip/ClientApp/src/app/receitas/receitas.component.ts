import { Component, Inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Receita } from '../models/receita.model';

@Component({
  selector: 'app-receitas',
  templateUrl: './receitas.component.html',
  styleUrls: ['./receitas.component.css']
})
export class ReceitasComponent implements OnInit {
  public receitas: Receita[] = [];
  public novaReceita: Receita = { id: 0, nome: '', instrucoes: '', ingredientes: '', url: '' };
  public receitaCriada: boolean = false;
  public erroPreenchimento: boolean = false;

  constructor(private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) { }

  ngOnInit(): void {
    this.loadReceitas();
  }

  loadReceitas() {
    this.http.get<Receita[]>(this.baseUrl + 'ReceitaModels').subscribe(
      (result) => {
        this.receitas = result;
      },
      (error) => {
        console.error(error);
      }
    );
  }

  updateReceita(receita: Receita) {
    console.log('Receita atualizada:', receita);
  }

  deleteReceita(receita: Receita) {
    const confirmDelete = confirm('Tem a certeza que deseja eliminar a receita?');

    if (confirmDelete) {
      this.http.delete(this.baseUrl + `ReceitaModels/${receita.id}`).subscribe(
        () => {
          console.log('Receita excluída:', receita);
          this.loadReceitas();
        },
        () => {
          console.log('Erro ao excluir receita');
        }
      );
    }
  }

  editReceita(receita: Receita) {
    console.log('editar-receitas/:id', receita);
  }

  createReceita() {
    if (!this.novaReceita.nome || !this.novaReceita.instrucoes || !this.novaReceita.ingredientes) {
      this.erroPreenchimento = true;
      this.receitaCriada = false;
    } else {
      this.http.post<Receita>(this.baseUrl + 'ReceitaModels', this.novaReceita).subscribe(
        () => {
          console.log('Receita criada:', this.novaReceita);
          this.receitaCriada = true;
          this.erroPreenchimento = false;
          this.novaReceita = { id: 0, nome: '', instrucoes: '', ingredientes: '', url: '' };
          this.loadReceitas();
        },
        () => {
          console.log('Erro ao criar receita');
          this.receitaCriada = false;
          this.erroPreenchimento = false;
        }
      );
    }
  }
}
