import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TodasReceitasComponent } from './todas-receitas.component';

describe('TodasReceitasComponent', () => {
  let component: TodasReceitasComponent;
  let fixture: ComponentFixture<TodasReceitasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TodasReceitasComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TodasReceitasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
