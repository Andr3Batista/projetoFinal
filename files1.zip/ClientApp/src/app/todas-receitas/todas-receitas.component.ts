import { Component, Inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Receita } from '../models/receita.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-todas-receitas',
  templateUrl: './todas-receitas.component.html',
  styleUrls: ['./todas-receitas.component.css']
})
export class TodasReceitasComponent implements OnInit {
  public receitas: Receita[] = [];

  constructor(private http: HttpClient, private router: Router, @Inject('BASE_URL') private baseUrl: string) { }

  ngOnInit(): void {
    this.loadReceitas();
  }

  loadReceitas(): void {
    this.http.get<Receita[]>(this.baseUrl + 'ReceitaModels').subscribe(
      result => {
        this.receitas = result.slice(0, 20);
      },
      error => {
        console.error(error);
      }
    );
  }

  openReceita(receita: Receita): void {
    this.router.navigate(['/detalhes-receitas', receita.id]);
  }
}
