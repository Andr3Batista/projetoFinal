﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DiogoNovo.Data;

namespace DiogoNovo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AvaliacaoModelsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AvaliacaoModelsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/AvaliacaoModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AvaliacaoModel>>> GetAvaliacaoModel()
        {
          if (_context.AvaliacaoModel == null)
          {
              return NotFound();
          }
            return await _context.AvaliacaoModel.ToListAsync();
        }

        // GET: api/AvaliacaoModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AvaliacaoModel>> GetAvaliacaoModel(int id)
        {
          if (_context.AvaliacaoModel == null)
          {
              return NotFound();
          }
            var avaliacaoModel = await _context.AvaliacaoModel.FindAsync(id);

            if (avaliacaoModel == null)
            {
                return NotFound();
            }

            return avaliacaoModel;
        }

        // PUT: api/AvaliacaoModels/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAvaliacaoModel(int id, AvaliacaoModel avaliacaoModel)
        {
            if (id != avaliacaoModel.Id)
            {
                return BadRequest();
            }

            _context.Entry(avaliacaoModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AvaliacaoModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AvaliacaoModels
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AvaliacaoModel>> PostAvaliacaoModel(AvaliacaoModel avaliacaoModel)
        {
          if (_context.AvaliacaoModel == null)
          {
              return Problem("Entity set 'ApplicationDbContext.AvaliacaoModel'  is null.");
          }
            _context.AvaliacaoModel.Add(avaliacaoModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAvaliacaoModel", new { id = avaliacaoModel.Id }, avaliacaoModel);
        }

        // DELETE: api/AvaliacaoModels/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAvaliacaoModel(int id)
        {
            if (_context.AvaliacaoModel == null)
            {
                return NotFound();
            }
            var avaliacaoModel = await _context.AvaliacaoModel.FindAsync(id);
            if (avaliacaoModel == null)
            {
                return NotFound();
            }

            _context.AvaliacaoModel.Remove(avaliacaoModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AvaliacaoModelExists(int id)
        {
            return (_context.AvaliacaoModel?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
