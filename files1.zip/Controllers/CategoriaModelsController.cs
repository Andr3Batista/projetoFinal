﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DiogoNovo.Data;

namespace DiogoNovo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriaModelsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CategoriaModelsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/CategoriaModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CategoriaModel>>> GetCategoriaModel()
        {
          if (_context.CategoriaModel == null)
          {
              return NotFound();
          }
            return await _context.CategoriaModel.ToListAsync();
        }

        // GET: api/CategoriaModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CategoriaModel>> GetCategoriaModel(int id)
        {
          if (_context.CategoriaModel == null)
          {
              return NotFound();
          }
            var categoriaModel = await _context.CategoriaModel.FindAsync(id);

            if (categoriaModel == null)
            {
                return NotFound();
            }

            return categoriaModel;
        }

        // PUT: api/CategoriaModels/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategoriaModel(int id, CategoriaModel categoriaModel)
        {
            if (id != categoriaModel.Id)
            {
                return BadRequest();
            }

            _context.Entry(categoriaModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CategoriaModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CategoriaModels
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<CategoriaModel>> PostCategoriaModel(CategoriaModel categoriaModel)
        {
          if (_context.CategoriaModel == null)
          {
              return Problem("Entity set 'ApplicationDbContext.CategoriaModel'  is null.");
          }
            _context.CategoriaModel.Add(categoriaModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCategoriaModel", new { id = categoriaModel.Id }, categoriaModel);
        }

        // DELETE: api/CategoriaModels/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategoriaModel(int id)
        {
            if (_context.CategoriaModel == null)
            {
                return NotFound();
            }
            var categoriaModel = await _context.CategoriaModel.FindAsync(id);
            if (categoriaModel == null)
            {
                return NotFound();
            }

            _context.CategoriaModel.Remove(categoriaModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CategoriaModelExists(int id)
        {
            return (_context.CategoriaModel?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
