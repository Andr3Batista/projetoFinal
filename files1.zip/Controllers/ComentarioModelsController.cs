﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DiogoNovo.Data;

namespace DiogoNovo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComentarioModelsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ComentarioModelsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/ComentarioModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ComentarioModel>>> GetComentarioModel()
        {
          if (_context.ComentarioModel == null)
          {
              return NotFound();
          }
            return await _context.ComentarioModel.ToListAsync();
        }

        // GET: api/ComentarioModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ComentarioModel>> GetComentarioModel(int id)
        {
          if (_context.ComentarioModel == null)
          {
              return NotFound();
          }
            var comentarioModel = await _context.ComentarioModel.FindAsync(id);

            if (comentarioModel == null)
            {
                return NotFound();
            }

            return comentarioModel;
        }

        // PUT: api/ComentarioModels/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutComentarioModel(int id, ComentarioModel comentarioModel)
        {
            if (id != comentarioModel.Id)
            {
                return BadRequest();
            }

            _context.Entry(comentarioModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ComentarioModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ComentarioModels
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ComentarioModel>> PostComentarioModel(ComentarioModel comentarioModel)
        {
          if (_context.ComentarioModel == null)
          {
              return Problem("Entity set 'ApplicationDbContext.ComentarioModel'  is null.");
          }
            _context.ComentarioModel.Add(comentarioModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetComentarioModel", new { id = comentarioModel.Id }, comentarioModel);
        }

        // DELETE: api/ComentarioModels/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteComentarioModel(int id)
        {
            if (_context.ComentarioModel == null)
            {
                return NotFound();
            }
            var comentarioModel = await _context.ComentarioModel.FindAsync(id);
            if (comentarioModel == null)
            {
                return NotFound();
            }

            _context.ComentarioModel.Remove(comentarioModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ComentarioModelExists(int id)
        {
            return (_context.ComentarioModel?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
