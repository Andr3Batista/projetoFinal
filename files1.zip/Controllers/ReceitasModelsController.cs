﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DiogoNovo.Data;

namespace DiogoNovo.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ReceitaModelsController : ControllerBase
    {
        private readonly ApplicationDbContext _context; // Certifique-se de ajustar o contexto

        public ReceitaModelsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ReceitaModel>>> GetReceitaModels()
        {
            return await _context.ReceitaModels.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ReceitaModel>> GetReceitaModel(int id)
        {
            var receitaModel = await _context.ReceitaModels.FindAsync(id);

            if (receitaModel == null)
            {
                return NotFound();
            }

            return receitaModel;
        }

        [HttpPost]
        public async Task<ActionResult<ReceitaModel>> PostReceitaModel(ReceitaModel receitaModel)
        {
            _context.ReceitaModels.Add(receitaModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetReceitaModel", new { id = receitaModel.Id }, receitaModel);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteReceitaModel(int id)
        {
            var receitaModel = await _context.ReceitaModels.FindAsync(id);
            if (receitaModel == null)
            {
                return NotFound();
            }

            _context.ReceitaModels.Remove(receitaModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
