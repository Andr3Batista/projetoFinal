﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DiogoNovo.Data;

namespace DiogoNovo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilizadorModelsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public UtilizadorModelsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/UtilizadorModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UtilizadorModel>>> GetUtilizadorModel()
        {
          if (_context.UtilizadorModel == null)
          {
              return NotFound();
          }
            return await _context.UtilizadorModel.ToListAsync();
        }

        // GET: api/UtilizadorModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<UtilizadorModel>> GetUtilizadorModel(int id)
        {
          if (_context.UtilizadorModel == null)
          {
              return NotFound();
          }
            var utilizadorModel = await _context.UtilizadorModel.FindAsync(id);

            if (utilizadorModel == null)
            {
                return NotFound();
            }

            return utilizadorModel;
        }

        // PUT: api/UtilizadorModels/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUtilizadorModel(int id, UtilizadorModel utilizadorModel)
        {
            if (id != utilizadorModel.Id)
            {
                return BadRequest();
            }

            _context.Entry(utilizadorModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UtilizadorModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/UtilizadorModels
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<UtilizadorModel>> PostUtilizadorModel(UtilizadorModel utilizadorModel)
        {
          if (_context.UtilizadorModel == null)
          {
              return Problem("Entity set 'ApplicationDbContext.UtilizadorModel'  is null.");
          }
            _context.UtilizadorModel.Add(utilizadorModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUtilizadorModel", new { id = utilizadorModel.Id }, utilizadorModel);
        }

        // DELETE: api/UtilizadorModels/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUtilizadorModel(int id)
        {
            if (_context.UtilizadorModel == null)
            {
                return NotFound();
            }
            var utilizadorModel = await _context.UtilizadorModel.FindAsync(id);
            if (utilizadorModel == null)
            {
                return NotFound();
            }

            _context.UtilizadorModel.Remove(utilizadorModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool UtilizadorModelExists(int id)
        {
            return (_context.UtilizadorModel?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
