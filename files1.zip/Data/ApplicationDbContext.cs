﻿using DiogoNovo.Models;
using Duende.IdentityServer.EntityFramework.Options;
using Microsoft.AspNetCore.ApiAuthorization.IdentityServer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace DiogoNovo.Data
{
    public class ApplicationDbContext : ApiAuthorizationDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions options, IOptions<OperationalStoreOptions> operationalStoreOptions)
            : base(options, operationalStoreOptions)
        {

        }
        public DbSet<AvaliacaoModel> AvaliacaoModel { get; set; } = default!;
        public DbSet<CategoriaModel> CategoriaModel { get; set; } = default!;
        public DbSet<ComentarioModel> ComentarioModel { get; set; } = default!;
        public DbSet<ReceitaModel> ReceitaModels { get; set; } = default!;
        public DbSet<UtilizadorModel> UtilizadorModel { get; set; } = default!;
    }
}