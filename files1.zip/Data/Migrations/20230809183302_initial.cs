﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DiogoNovo.Data.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_ReceitaModel",
                table: "ReceitaModel");

            migrationBuilder.RenameTable(
                name: "ReceitaModel",
                newName: "ReceitaModels");

            migrationBuilder.AddColumn<string>(
                name: "Url",
                table: "ReceitaModels",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReceitaModels",
                table: "ReceitaModels",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_ReceitaModels",
                table: "ReceitaModels");

            migrationBuilder.DropColumn(
                name: "Url",
                table: "ReceitaModels");

            migrationBuilder.RenameTable(
                name: "ReceitaModels",
                newName: "ReceitaModel");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReceitaModel",
                table: "ReceitaModel",
                column: "Id");
        }
    }
}
