﻿using Microsoft.AspNetCore.Identity;

namespace DiogoNovo.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string FullName { get; set; }
        public DateTime BirthDate { get; set; }

        public int CalculateAge()
        {
            if (BirthDate == DateTime.MinValue) // Verifica se a data de nascimento é válida
            {
                return 0; // Retorna 0 em caso de data de nascimento inválida
            }

            DateTime currentDate = DateTime.Now;
            int age = currentDate.Year - BirthDate.Year;

            // Verifica se o aniversário do usuário ainda não ocorreu este ano
            if (currentDate < BirthDate.AddYears(age))
            {
                age--;
            }

            return age;
        }
    }
}