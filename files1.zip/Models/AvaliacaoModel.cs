﻿public class AvaliacaoModel
{
    public int Id { get; set; }
    public int IdReceita { get; set; }
    public int IdUtilizador { get; set; }
    public int Pontuacao { get; set; }
    public DateTime DataAvaliacao { get; set; }
}
