﻿public class ReceitaModel
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Ingredientes { get; set; }
    public string Instrucoes { get; set; }
    public string Url { get; set; }
    public DateTime DataCriacao { get; set; }
}
